from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Profile(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Add this line to link the profile to a user

    def __str__(self):
        return self.name if self.name else 'Profile'

    name = models.CharField(max_length=200, default="")
    email = models.CharField(max_length=200, default="")
    phone = models.CharField(max_length=200, default="")
    linkedin = models.URLField(max_length=200, blank=True, null=True)
    objective = models.CharField(max_length=1000, default="")
    highschool = models.CharField(max_length=200, default="")
    highschoolPercentage = models.CharField(max_length=200, default="")
    higherSecondary = models.CharField(max_length=200, default="")
    higherSecondaryPercentage = models.CharField(max_length=200, default="")
    college = models.CharField(max_length=200, blank=True, null=True)
    cgpa = models.CharField(max_length=200, default="")
    university = models.CharField(max_length=200, default="", blank=True, null=True)
    univcgpa = models.CharField(max_length=200, default="")
    achievement = models.CharField(max_length=200, default="", blank=True, null=True)
    achievementdetails = models.CharField(max_length=2000, default="", blank=True, null=True)
    universitydegree = models.CharField(max_length=200, default="", blank=True, null=True)
    collegedegree = models.CharField(max_length=200, default="", blank=True, null=True)
    project1 = models.CharField(max_length=300, default="", blank=True, null=True)
    project1details = models.CharField(max_length=2000, default="", blank=True, null=True)
    project2 = models.CharField(max_length=300, default="", blank=True, null=True)
    project2details = models.CharField(max_length=2000, default="", blank=True)
    project3 = models.CharField(max_length=300, default="", blank=True, null=True)
    project3details = models.CharField(max_length=2000, default="", blank=True, null=True)
    work1 = models.CharField(max_length=300, default="", blank=True, null=True)
    work1details = models.CharField(max_length=2000, default="", blank=True, null=True)
    work2 = models.CharField(max_length=300, default="", blank=True, null=True)
    work2details = models.CharField(max_length=2000, default="", blank=True, null=True)
    work3 = models.CharField(max_length=300, default="", blank=True, null=True)
    work3details = models.CharField(max_length=2000, default="", blank=True, null=True)
    skill1 = models.CharField(max_length=200, default="", blank=True, null=True)
    skill2 = models.CharField(max_length=200, default="", blank=True, null=True)
    skill3 = models.CharField(max_length=200, default="", blank=True, null=True)
    skill4 = models.CharField(max_length=200, default="", blank=True, null=True)
    skill5 = models.CharField(max_length=200, default="", blank=True, null=True)
    cert1 = models.CharField(max_length=200, default="", blank=True, null=True)
    cert2 = models.CharField(max_length=200, default="", blank=True, null=True)
