from django.conf import settings
from django.shortcuts import redirect, render
from .models import Profile
import pdfkit
from django.http import HttpResponse
from django.template import loader
import io  
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def form(request):
    if request.method == "POST":
        name = request.POST.get("name","")
        email = request.POST.get("email","")
        linkedin = request.POST.get("linkedin","")
        objective = request.POST.get("objective","")
        phone = request.POST.get("phone","")
        highschool = request.POST.get("highschool","")
        highschoolPercentage = request.POST.get("highschoolPercentage","")
        higherSecondary = request.POST.get("higherSecondary","")
        higherSecondaryPercentage = request.POST.get("higherSecondaryPercentage","")
        college = request.POST.get("college","")
        collegedegree = request.POST.get("collegedegree","")
        cgpa = request.POST.get("cgpa","")
        university = request.POST.get("university","")
        univcgpa = request.POST.get("univcgpa","") 
        universitydegree = request.POST.get("universitydegree","")
        achievement = request.POST.get("achievement","")
        achievementdetails = request.POST.get("achievementdetails","")
        project1 = request.POST.get("project1","")
        project1details = request.POST.get("project1details","")
        project2 = request.POST.get("project2","")
        project2details = request.POST.get("project2details","")
        project3 = request.POST.get("project3","")
        project3details = request.POST.get("project3details","")
        work1 = request.POST.get("work1","")
        work1details = request.POST.get("work1details","")
        work2 = request.POST.get("work2","")
        work2details = request.POST.get("work2details","")
        work3 = request.POST.get("work3","")
        work3details = request.POST.get("work3details","")
        skill1 = request.POST.get("skill1","")
        skill2 = request.POST.get("skill2","")
        skill3 = request.POST.get("skill3","")
        skill4 = request.POST.get("skill4","")
        skill5 = request.POST.get("skill5","")
        cert1 = request.POST.get("cert1","")
        cert2 = request.POST.get("cert2","")




        profile = Profile.objects.create(name=name,email=email,linkedin=linkedin,achievementdetails=achievementdetails,college=college,objective=objective,phone=phone,highschool=highschool,highschoolPercentage=highschoolPercentage,higherSecondary=higherSecondary,higherSecondaryPercentage=higherSecondaryPercentage,university=university,univcgpa=univcgpa,collegedegree=collegedegree,universitydegree=universitydegree,cgpa=cgpa,achievement=achievement,project1=project1,project1details=project1details,project2=project2,project2details=project2details,project3=project3,project3details=project3details,work1=work1,work1details=work1details,work2=work2,work2details=work2details,work3=work3,work3details=work3details,skill1=skill1,skill2=skill2,skill3=skill3,skill4=skill4,skill5=skill5,cert1=cert1,cert2=cert2)
        profile.save()
    return render(request,'pdf/form.html')

def header(request):
    return render(request,'pdf/header.html')

def home(request):
    return render(request,'pdf/home.html')

def about(request):
    return render(request,'pdf/about.html')

def checkout(request):
    return render(request,'pdf/checkout.html')


def resume(request,id):
    user_profile = Profile.objects.get(pk=id)
    template = loader.get_template('pdf/resume.html')
    
    # Get the base URL of the Django project
    base_url = request.build_absolute_uri(settings.STATIC_URL)
    
    # Render the HTML template with the base URL included
    html = template.render({'user_profile': user_profile, 'base_url': base_url})
    
    options = {
        'page-size': 'Letter',
        'encoding': "UTF-8",
        "enable-local-file-access": "",
    }
    pdf = pdfkit.from_string(html, False, options)
    
    # Create the PDF response
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="resume.pdf"'
    

    return response

@login_required
def checkout(request):
    current_user_profile = Profile.objects.filter(user=request.user).first()

    user = request.user

    if request.method == "POST":
        name = request.POST.get("name","")
        email = request.POST.get("email","")
        linkedin = request.POST.get("linkedin","")
        objective = request.POST.get("objective","")
        phone = request.POST.get("phone","")
        highschool = request.POST.get("highschool","")
        highschoolPercentage = request.POST.get("highschoolPercentage","")
        higherSecondary = request.POST.get("higherSecondary","")
        higherSecondaryPercentage = request.POST.get("higherSecondaryPercentage","")
        college = request.POST.get("college","")
        collegedegree = request.POST.get("collegedegree","")
        cgpa = request.POST.get("cgpa","")
        university = request.POST.get("university","")
        univcgpa = request.POST.get("univcgpa","") 
        universitydegree = request.POST.get("universitydegree","")
        achievement = request.POST.get("achievement","")
        achievementdetails = request.POST.get("achievementdetails","")
        project1 = request.POST.get("project1","")
        project1details = request.POST.get("project1details","")
        project2 = request.POST.get("project2","")
        project2details = request.POST.get("project2details","")
        project3 = request.POST.get("project3","")
        project3details = request.POST.get("project3details","")
        work1 = request.POST.get("work1","")
        work1details = request.POST.get("work1details","")
        work2 = request.POST.get("work2","")
        work2details = request.POST.get("work2details","")
        work3 = request.POST.get("work3","")
        work3details = request.POST.get("work3details","")
        skill1 = request.POST.get("skill1","")
        skill2 = request.POST.get("skill2","")
        skill3 = request.POST.get("skill3","")
        skill4 = request.POST.get("skill4","")
        skill5 = request.POST.get("skill5","")
        cert1 = request.POST.get("cert1","")
        cert2 = request.POST.get("cert2","")




        profile = Profile.objects.create(user=user,name=name,email=email,linkedin=linkedin,achievementdetails=achievementdetails,college=college,objective=objective,phone=phone,highschool=highschool,highschoolPercentage=highschoolPercentage,higherSecondary=higherSecondary,higherSecondaryPercentage=higherSecondaryPercentage,university=university,univcgpa=univcgpa,collegedegree=collegedegree,universitydegree=universitydegree,cgpa=cgpa,achievement=achievement,project1=project1,project1details=project1details,project2=project2,project2details=project2details,project3=project3,project3details=project3details,work1=work1,work1details=work1details,work2=work2,work2details=work2details,work3=work3,work3details=work3details,skill1=skill1,skill2=skill2,skill3=skill3,skill4=skill4,skill5=skill5,cert1=cert1,cert2=cert2)
        profile.save()

    return render(request, 'pdf/checkout.html', {'profile': current_user_profile})

